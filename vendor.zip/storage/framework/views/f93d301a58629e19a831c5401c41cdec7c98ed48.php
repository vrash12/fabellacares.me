<?php
    $layout = auth()->user()->role === 'encoder'
            ? 'layouts.encoder'
            : 'layouts.admin';
?>




<?php $__env->startSection('content'); ?>
<div class="page-header mb-4 d-flex justify-content-between align-items-center">
  <h1 class="h3">High-Risk Submissions (OPD-F-09)</h1>
  <a href="<?php echo e(route('high-risk-opd-forms.create')); ?>" class="btn btn-primary">
    <i class="bi bi-plus-lg"></i> New High-Risk
  </a>
</div>

<div class="card shadow-sm">
  <div class="card-body p-0">
    <table class="table table-striped mb-0">
      <thead>
        <tr>
          <th>#</th>
          <th>Patient</th>
          <th>Created At</th>
          <th class="text-end">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $submissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td><?php echo e($sub->id); ?></td>
            <td>
              <?php if($sub->patient): ?>
                <?php echo e($sub->patient->name); ?>

              <?php else: ?>
                <?php echo e(trim(
                      data_get($sub->answers,'last_name','')
                    .' '
                    .data_get($sub->answers,'given_name','')
                  ) ?: '— unassigned'); ?>

              <?php endif; ?>
            </td>
            <td><?php echo e($sub->created_at->format('Y-m-d H:i')); ?></td>
            <td class="text-end">
              <a href="<?php echo e(route('high-risk-opd-forms.show', $sub)); ?>"
                 class="btn btn-sm btn-secondary">View</a>
              <a href="<?php echo e(route('high-risk-opd-forms.edit', $sub)); ?>"
                 class="btn btn-sm btn-info">Edit</a>
              <form action="<?php echo e(route('high-risk-opd-forms.destroy', $sub)); ?>"
                    method="POST"
                    class="d-inline"
                    onsubmit="return confirm('Delete this submission?');">
                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                <button class="btn btn-sm btn-danger">Delete</button>
              </form>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr>
            <td colspan="4" class="text-center py-4">
              No high-risk submissions yet.
            </td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MAURICIO\Documents\fabel\resources\views/opd_forms/high_risk/index.blade.php ENDPATH**/ ?>