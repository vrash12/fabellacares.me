<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Work Schedules Report</title>
  <style>
    body { font-family: sans-serif; font-size: 11px; }
    h2   { margin-bottom: .4em; }
    table { width: 100%; border-collapse: collapse; margin-top: .5em; }
    th,td { border: 1px solid #000; padding: 4px; text-align: left; }
    th { background: #eee; }
  </style>
</head>
<body>
  <h2>Work Schedules Report</h2>
  <p>From: <?php echo e($from); ?>  To: <?php echo e($to); ?></p>

  <table>
    <thead>
      <tr>
        <th>Department</th>
        <th>Staff Name</th>
        <th>Role</th>
        <th>Date</th>
        <th>Start Day</th>
        <th>Shift Length (hrs)</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($s->department); ?></td>
          <td><?php echo e($s->staff_name); ?></td>
          <td><?php echo e(ucfirst($s->role)); ?></td>
          <td><?php echo e($s->date); ?></td>
          <td><?php echo e($s->start_day); ?></td>
          <td><?php echo e($s->shift_length); ?></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</body>
</html>
<?php /**PATH C:\Users\MAURICIO\Documents\fabel\resources\views/reports/schedules_pdf.blade.php ENDPATH**/ ?>