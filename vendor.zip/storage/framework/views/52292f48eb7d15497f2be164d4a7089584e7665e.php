<?php $__env->startSection('content'); ?>
  <div class="container py-4">

    
    <div class="d-flex align-items-center justify-content-between mb-4">
      <h1 class="h3 mb-0">
        <i class="bi bi-person-lines-fill me-2"></i>
        Patient Record: <?php echo e($patient->name); ?>

      </h1>
      <div>
        <a href="<?php echo e(route('patients.index')); ?>" class="btn btn-outline-secondary">
          <i class="bi bi-arrow-left-circle me-1"></i> Back to List
        </a>
      </div>
    </div>

    
    <ul class="nav nav-tabs mb-4" role="tablist" style="pointer-events: none;">
      <li class="nav-item" role="presentation">
        <span class="nav-link active">
          <i class="bi bi-person me-1"></i> Overview
        </span>
      </li>
      <li class="nav-item" role="presentation">
        <span class="nav-link">
          <i class="bi bi-journal-text me-1"></i> Patient History
        </span>
      </li>
    </ul>

    
    <div class="p-4 mb-4 bg-white shadow-sm rounded">
      
      <div class="card mb-4 shadow-sm">
        <div class="card-header bg-primary text-white">
          <i class="bi bi-info-circle me-2"></i> Basic Information
        </div>
        <div class="card-body">
          <div class="row">
            <div class="col-md-6 mb-3">
              <strong>Name:</strong> <?php echo e($patient->name); ?>

            </div>
            <div class="col-md-6 mb-3">
              <strong>Birth Date:</strong>
              <?php echo e($patient->birth_date
                  ? \Carbon\Carbon::parse($patient->birth_date)->format('F j, Y')
                  : '—'); ?>

            </div>
          </div>
          <div class="row">
            <div class="col-md-6 mb-3">
              <strong>Contact No.:</strong> <?php echo e($patient->contact_no ?? '—'); ?>

            </div>
            <div class="col-md-6 mb-3">
              <strong>Address:</strong> <?php echo e($patient->address ?? '—'); ?>

            </div>
          </div>
          <div class="row">
            <div class="col-md-4 mb-3">
              <strong>Sex:</strong> <?php echo e(ucfirst($patient->profile->sex ?? '—')); ?>

            </div>
            <div class="col-md-4 mb-3">
              <strong>Religion:</strong> <?php echo e($patient->profile->religion ?? '—'); ?>

            </div>
            <div class="col-md-4 mb-3">
              <strong>Age:</strong>
              <?php if($patient->birth_date): ?>
                <?php echo e(\Carbon\Carbon::parse($patient->birth_date)->age); ?> years
              <?php else: ?>
                —
              <?php endif; ?>
            </div>
          </div>
        </div>
      </div>

      
      <div class="card mb-4 shadow-sm">
        <div class="card-header bg-success text-white">
          <i class="bi bi-clipboard-data me-2"></i> Patient Details & Visits
        </div>
        <div class="card-body">
          <div class="row mb-3">
            <?php if(isset($patient->record_no)): ?>
              <div class="col-md-4 mb-2">
                <strong>Record No.:</strong> <?php echo e($patient->record_no); ?>

              </div>
            <?php endif; ?>

            <div class="col-md-4 mb-2">
              <strong>Total Visits:</strong>
              <span class="badge bg-info"><?php echo e($patient->visits->count()); ?></span>
            </div>

            <?php if(isset($patient->profile->blood_type)): ?>
              <div class="col-md-4 mb-2">
                <strong>Blood Type:</strong> <?php echo e($patient->profile->blood_type); ?>

              </div>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>

    
    <div class="p-4 bg-white shadow-sm rounded">
      <div class="card shadow-sm h-100">
        <div class="card-header bg-secondary text-white">
          <i class="bi bi-clock-history me-2"></i> Past Diagnoses & Records
        </div>
        <div class="card-body d-flex flex-column">
          <?php
            $visits    = $patient->visits;
            $highRisks = $patient->highRiskSubmissions;
          ?>

          
          <?php if($visits->isEmpty() && $highRisks->isEmpty()): ?>
            <div class="text-center text-muted py-5">
              <i class="bi bi-info-circle me-1"></i>
              No history available for this patient.
            </div>
          <?php else: ?>
            
            <h5 class="fw-bold mb-3">
              <i class="bi bi-hospital me-1"></i> Regular OPD Visits
            </h5>
            <div class="table-responsive mb-4">
              <table class="table table-bordered align-middle mb-0">
                <thead class="table-light text-center">
                  <tr>
                    <th>Date</th>
                    <th>Form No.</th>
                    <th>Type</th>
                    <th>Diagnosis / Notes</th>
                    <th class="text-center" style="width:140px;">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__empty_1 = true; $__currentLoopData = $visits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                      <td class="text-center"><?php echo e($visit->created_at->format('Y-m-d')); ?></td>
                      <td class="text-center"><?php echo e($visit->form->form_no ?? '—'); ?></td>
                      <td class="text-center"><?php echo e($visit->form->name ?? '—'); ?></td>
                      <td>
                        <?php echo e(\Illuminate\Support\Str::limit(
                          $visit->answers['diagnosis']
                          ?? $visit->answers['chief_complaint']
                          ?? '-',
                          60
                        )); ?>

                      </td>
                      <td class="text-center">
                        <a
                          href="<?php echo e(route('opd_submissions.show', $visit)); ?>"
                          class="btn btn-sm btn-secondary"
                          title="View Full Submission"
                        >
                          <i class="bi bi-eye"></i>
                        </a>
                      </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                      <td colspan="5" class="text-center text-muted py-4">
                        <i class="bi bi-inbox me-1"></i> No regular visits.
                      </td>
                    </tr>
                  <?php endif; ?>
                </tbody>
              </table>
            </div>

            
            <h5 class="fw-bold mb-3">
              <i class="bi bi-exclamation-triangle me-1"></i> High-Risk Records (OPD-F-09)
            </h5>
            <div class="table-responsive">
              <table class="table table-bordered align-middle mb-0">
                <thead class="table-light text-center">
                  <tr>
                    <th>Date</th>
                    <th>Risk Factors</th>
                    <th class="text-center" style="width:140px;">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__empty_1 = true; $__currentLoopData = $highRisks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $risk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                      <td class="text-center"><?php echo e($risk->created_at->format('Y-m-d')); ?></td>
                      <td>
                        <?php
                          $risks = $risk->answers['risks'] ?? [];
                          $preview = collect($risks)->take(3)->join(', ');
                        ?>
                        <?php echo e($preview); ?><?php echo e(count($risks) > 3 ? ' …' : ''); ?>

                      </td>
                      <td class="text-center">
                        <a
                          href="<?php echo e(route('high-risk-opd-forms.show', $risk)); ?>"
                          class="btn btn-sm btn-secondary"
                          title="View High-Risk Submission"
                        >
                          <i class="bi bi-eye"></i>
                        </a>
                      </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                      <td colspan="3" class="text-center text-muted py-4">
                        <i class="bi bi-inbox me-1"></i> No high-risk submissions.
                      </td>
                    </tr>
                  <?php endif; ?>
                </tbody>
              </table>
            </div>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MAURICIO\Documents\fabel\resources\views/patients/show.blade.php ENDPATH**/ ?>