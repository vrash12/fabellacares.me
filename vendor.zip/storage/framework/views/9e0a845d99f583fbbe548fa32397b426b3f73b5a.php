<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <style>
    body { font-family: sans-serif; }
    table { width: 100%; border-collapse: collapse; }
    th, td { border: 1px solid #ccc; padding: 6px; text-align: left; }
    th { background: #f0f0f0; }
  </style>
</head>
<body>
  <h2>OPD Patients</h2>
  <table>
    <thead>
      <tr>
        <th>#</th><th>Name</th><th>Sex</th><th>Age</th><th>Visits</th><th>Created</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($i+1); ?></td>
          <td><?php echo e($p->name); ?></td>
          <td><?php echo e(ucfirst($p->profile->sex ?? '—')); ?></td>
          <td><?php echo e($p->profile->birth_date ? now()->diffInYears($p->profile->birth_date) : '—'); ?></td>
          <td><?php echo e($p->visits_count); ?></td>
          <td><?php echo e($p->created_at->format('Y-m-d')); ?></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</body>
</html>
<?php /**PATH C:\Users\MAURICIO\Documents\fabel\resources\views/patients/pdf.blade.php ENDPATH**/ ?>