<?php
    $layout = auth()->user()->role === 'encoder'
            ? 'layouts.encoder'
            : 'layouts.admin';
?>



<?php $__env->startSection('content'); ?>
  <div class="container py-4">
    
    <div class="d-flex align-items-center justify-content-between mb-4">
      <h1 class="h3 mb-0">
        <i class="bi bi-pencil-square me-2"></i>
        Edit Follow-Up #<?php echo e($submission->id); ?>

      </h1>
      <div>
        
        <a href="<?php echo e(route('follow-up-opd-forms.show', [
                      'follow_up_opd_form' => $submission->id
                    ])); ?>"
           class="btn btn-outline-secondary">
          <i class="bi bi-eye me-1"></i> View
        </a>
      </div>
    </div>

    <div class="card shadow-sm">
      <div class="card-header bg-info text-white">
        Modify Answers
      </div>
      <div class="card-body">
        <form action="<?php echo e(route('follow-up-opd-forms.update', [
                              'follow_up_opd_form' => $submission->id
                          ])); ?>"
              method="POST">
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>

          
          <div class="mb-3">
            <label class="form-label">Follow-Up Entries (JSON Array)</label>
            <textarea name="followups"
                      class="form-control <?php $__errorArgs = ['followups'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                      rows="6"
                      placeholder='[{"date":"2025-05-01","gest_weeks":12,"weight":60,"bp":"120/80","remarks":"..."}]'><?php echo e(old('followups', json_encode($submission->answers['followups'] ?? [], JSON_UNESCAPED_SLASHES))); ?></textarea>
            <?php $__errorArgs = ['followups'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>

          

          <div class="d-flex justify-content-end">
            <button type="submit" class="btn btn-success me-2">
              <i class="bi bi-check-circle me-1"></i> Save Changes
            </button>
            <a href="<?php echo e(route('follow-up-opd-forms.show', [
                          'follow_up_opd_form' => $submission->id
                        ])); ?>"
               class="btn btn-secondary">
              Cancel
            </a>
          </div>
        </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MAURICIO\Documents\fabel\resources\views/opd_forms/follow_up/edit.blade.php ENDPATH**/ ?>