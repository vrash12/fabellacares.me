<?php $__env->startSection('content'); ?>
  <h1 class="mb-4">New OPD-OB Record</h1>

  <?php echo $__env->make('opd_forms.opdb._form', [
    'opd_form'   => null,
    'postRoute'  => route('ob-opd-forms.store'),
    'showButtons'=> true,
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
  $(function(){
    $('#region').ph_address_selector({
      dataPath:   '/ph-json',
      region:     '#region',
      province:   '#province',
      city:       '#city',
      barangay:   '#barangay',
      regionText:   '#region-text',
      provinceText: '#province-text',
      cityText:     '#city-text',
      barangayText: '#barangay-text',
    });
  });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MAURICIO\Documents\fabel\resources\views/opd_forms/opdb/create.blade.php ENDPATH**/ ?>