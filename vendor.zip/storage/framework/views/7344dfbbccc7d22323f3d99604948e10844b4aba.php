<?php
    $layout = auth()->user()->role === 'encoder'
            ? 'layouts.encoder'
            : 'layouts.admin';
?>




<?php $__env->startSection('content'); ?>
  <div class="page-header mb-4">
    <h1 class="h3">New Follow-Up Record (OPD-F-08)</h1>
  </div>
  <form method="POST" action="<?php echo e(route('follow-up-opd-forms.store')); ?>">
    <?php echo csrf_field(); ?>
    <?php echo $__env->make('opd_forms.follow_up._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="text-end mt-4">
      <a href="<?php echo e(route('follow-up-opd-forms.index')); ?>" class="btn btn-secondary">Cancel</a>
      <button type="submit" class="btn btn-primary">Save Record</button>
    </div>
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MAURICIO\Documents\fabel\resources\views/opd_forms/follow_up/create.blade.php ENDPATH**/ ?>