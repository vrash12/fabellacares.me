


<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('opd_forms.teens_triage._form', [
    'teensForm' => $teensForm ?? null,
    'postRoute' => isset($teensForm)
      ? route('triage.teens.update', $teensForm)
      : route('triage.teens.store')
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MAURICIO\Documents\fabel\resources\views/opd_forms/teens_triage/create.blade.php ENDPATH**/ ?>