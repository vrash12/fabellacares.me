

<?php
    // helper to pull old input or existing model data
    if (! function_exists('f')) {
        function f(string $key, $form) {
            return old($key, data_get($form, $key, ''));
        }
    }
?>

<form method="POST" action="<?php echo e($postRoute ?? route('triage.internal.store')); ?>">
    <?php echo csrf_field(); ?>

    <div class="text-center mb-4">
        <h2>🏥 INTERNAL MEDICINE TRIAGE FORM</h2>
    </div>

<div class="mb-4">
  <label class="form-label">Patient <span class="text-danger">*</span></label>
  <select name="patient_id"
          id="patient-select"
          class="form-select <?php $__errorArgs = ['patient_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
          data-placeholder="Search patient…">
    <?php if(isset($triageForm['patient_id'])): ?>
      <?php
        $p = \App\Models\Patient::find($triageForm['patient_id']);
      ?>
      <?php if($p): ?>
        <option value="<?php echo e($p->id); ?>" selected><?php echo e($p->name); ?></option>
      <?php endif; ?>
    <?php endif; ?>
  </select>
  <?php $__errorArgs = ['patient_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

    
    <h5>I. Chief Complaint</h5>
    <div class="mb-3">
        <label class="form-label">Chief Complaint</label>
        <input type="text"
               name="chief_complaint"
               value="<?php echo e(f('chief_complaint', $triageForm)); ?>"
               class="form-control">
    </div>

    
    <h5 class="mt-4">II. History of Present Illness</h5>
    <div class="row g-3 mb-3">
        <div class="col-md-4">
            <label class="form-label">Onset</label>
            <input type="text"
                   name="onset"
                   value="<?php echo e(f('onset', $triageForm)); ?>"
                   class="form-control">
        </div>
        <div class="col-md-4">
            <label class="form-label">Duration</label>
            <input type="text"
                   name="duration"
                   value="<?php echo e(f('duration', $triageForm)); ?>"
                   class="form-control">
        </div>
        <div class="col-md-4">
            <label class="form-label">Progression</label>
            <select name="progression" class="form-select">
                <option value="">Select…</option>
                <?php $__currentLoopData = ['Improving','Worsening','Unchanged']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($opt); ?>"
                        <?php echo e(f('progression', $triageForm)==$opt ? 'selected' : ''); ?>>
                        <?php echo e($opt); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>

    <label class="form-label">Associated symptoms</label>
    <div class="row mb-3">
        <?php
            $symptoms = [
              'Fever','Cough','Chest pain','Headache','Numbness',
              'Body weakness','Abdominal pain','Diarrhea','Vomiting','Palpitations'
            ];
            $checked = f('associated_symptoms', $triageForm) ?: [];
        ?>
        <?php $__currentLoopData = $symptoms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sym): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3 form-check">
                <input class="form-check-input"
                       type="checkbox"
                       name="associated_symptoms[]"
                       value="<?php echo e($sym); ?>"
                       <?php echo e(in_array($sym,$checked) ? 'checked' : ''); ?>>
                <label class="form-check-label"><?php echo e($sym); ?></label>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-6 mt-2">
            <label class="form-label">Others</label>
            <input type="text"
                   name="associated_symptoms_other"
                   value="<?php echo e(f('associated_symptoms_other', $triageForm)); ?>"
                   class="form-control">
        </div>
    </div>

    
    <h5 class="mt-4">III. Past Medical History</h5>
    <?php
      $conditions = [
        'Hypertension','Diabetes Mellitus','Asthma / COPD',
        'Heart disease','Tuberculosis','Stroke / Seizures'
      ];
    ?>
    <div class="row g-3 mb-3">
      <?php $__currentLoopData = $conditions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cond): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">
          <label class="form-label"><?php echo e($cond); ?></label>
          <select name="past_history[<?php echo e(Str::slug($cond)); ?>]" class="form-select">
            <option value="">Select…</option>
            <option value="Yes" <?php echo e(f("past_history.".Str::slug($cond), $triageForm)=='Yes' ? 'selected':''); ?>>Yes</option>
            <option value="No"  <?php echo e(f("past_history.".Str::slug($cond), $triageForm)=='No'  ? 'selected':''); ?>>No</option>
          </select>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <div class="col-md-6">
        <label class="form-label">Others</label>
        <input type="text"
               name="past_history[others]"
               value="<?php echo e(f('past_history.others', $triageForm)); ?>"
               class="form-control">
      </div>
    </div>

    
    <h5 class="mt-4">IV. Medications and Allergies</h5>
    <div class="row g-3 mb-3">
      <div class="col-md-6">
        <label class="form-label">Current Medications</label>
        <input type="text"
               name="current_medications"
               value="<?php echo e(f('current_medications', $triageForm)); ?>"
               class="form-control">
      </div>
      <div class="col-md-6">
        <label class="form-label">Allergies</label>
        <input type="text"
               name="allergies"
               value="<?php echo e(f('allergies', $triageForm)); ?>"
               class="form-control">
      </div>
    </div>

    
    <h5 class="mt-4">V. Vital Signs</h5>
    <div class="row g-3 mb-4">
      <div class="col-md-3">
        <label class="form-label">BP (mmHg)</label>
        <div class="input-group">
          <input type="number" name="bp_systolic" value="<?php echo e(f('bp_systolic', $triageForm)); ?>" class="form-control" placeholder="Systolic">
          <span class="input-group-text">/</span>
          <input type="number" name="bp_diastolic" value="<?php echo e(f('bp_diastolic', $triageForm)); ?>" class="form-control" placeholder="Diastolic">
        </div>
      </div>
      <div class="col-md-2">
        <label class="form-label">HR (bpm)</label>
        <input type="number"
               name="heart_rate"
               value="<?php echo e(f('heart_rate', $triageForm)); ?>"
               class="form-control">
      </div>
      <div class="col-md-2">
        <label class="form-label">RR (cpm)</label>
        <input type="number"
               name="resp_rate"
               value="<?php echo e(f('resp_rate', $triageForm)); ?>"
               class="form-control">
      </div>
      <div class="col-md-2">
        <label class="form-label">Temp (°C)</label>
        <input type="number" step="0.1"
               name="temperature"
               value="<?php echo e(f('temperature', $triageForm)); ?>"
               class="form-control">
      </div>
      <div class="col-md-1">
        <label class="form-label">Height (cm)</label>
        <input type="number"
               name="height"
               value="<?php echo e(f('height', $triageForm)); ?>"
               class="form-control">
      </div>
      <div class="col-md-1">
        <label class="form-label">Weight (kg)</label>
        <input type="number"
               name="weight"
               value="<?php echo e(f('weight', $triageForm)); ?>"
               class="form-control">
      </div>
      <div class="col-md-3">
        <label class="form-label">Blood Sugar (mg/dL)</label>
        <input type="number" step="0.1"
               name="blood_sugar"
               value="<?php echo e(f('blood_sugar', $triageForm)); ?>"
               class="form-control">
      </div>
    </div>

    
    <button type="submit" class="btn btn-primary">
      <?php echo e(isset($triageForm) ? 'Update Triage' : 'Save Triage'); ?>

    </button>
</form>
<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', () => {
   $('#patient-select').select2({
      theme: 'bootstrap-5',
      minimumInputLength: 2,
      ajax: {
         url: '<?php echo e(route('patients.search')); ?>',
         data: params => ({ q: params.term }),
         processResults: data => ({ results: data.results })
      }
   });
});
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\Users\MAURICIO\Documents\fabel\resources\views/opd_forms/internal_medicine_triage/_form.blade.php ENDPATH**/ ?>