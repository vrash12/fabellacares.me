<?php $__env->startSection('content'); ?>
  <div class="container py-4">
    
    <div class="d-flex justify-content-between align-items-center mb-4">
      <a href="<?php echo e(route('queue.delete.select')); ?>" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left me-2"></i>Back to Queue Selection
      </a>
      <h2>Delete Tokens from “<?php echo e($queue->name); ?>”</h2>
      <div style="width: 180px;"></div>
    </div>

    <?php if($tokens->isEmpty()): ?>
      <div class="alert alert-info">
        There are no pending tokens in this queue.
      </div>
    <?php else: ?>
      <div class="table-responsive">
        <table class="table table-striped table-hover align-middle">
          <thead class="table-dark">
            <tr>
              <th style="width: 60px;">#</th>
              <th>Token Code</th>
              <th>Requested At</th>
              <th style="width: 150px;">Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $tokens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $token): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                
                <td><?php echo e(($tokens->currentPage() - 1) * $tokens->perPage() + $idx + 1); ?></td>
                <td><?php echo e($token->code); ?></td>
                <td><?php echo e($token->created_at->format('M d, Y H:i:s')); ?></td>
                <td>
                  <form
                    action="<?php echo e(route('queue.delete.token', ['queue' => $queue->id, 'token' => $token->id])); ?>"
                    method="POST"
                    onsubmit="return confirm('Are you sure you want to delete token <?php echo e($token->code); ?>?');"
                  >
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-sm btn-danger">
                      <i class="bi bi-trash me-1"></i>Delete
                    </button>
                  </form>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>

      
      <div class="mt-3">
        <?php echo e($tokens->withQueryString()->links('pagination::bootstrap-5')); ?>

      </div>
    <?php endif; ?>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MAURICIO\Documents\fabel\resources\views/queue/delete_list.blade.php ENDPATH**/ ?>