
<?php
    $layout = auth()->user()->role === 'encoder'
            ? 'layouts.encoder'
            : 'layouts.admin';
?>



<?php $__env->startSection('content'); ?>
<div class="container col-lg-8">
  <div class="page-header mb-4">
    <h2 class="m-0">Triage Form Details</h2>
  </div>

  
  <div class="mb-3">
    <strong>Patient:</strong>
    <?php echo e($triageForm->patient->name); ?>

  </div>

  
  <h4>I. Tetanus Series</h4>
  <table class="table table-sm mb-4">
    <thead>
      <tr>
        <th>Dose</th>
        <th>Date</th>
        <th>Signature</th>
      </tr>
    </thead>
    <tbody>
      <?php for($i = 1; $i <= 5; $i++): ?>
      <tr>
        <td>T<?php echo e($i); ?></td>
        <td><?php echo e(optional($triageForm)->{"tetanus_t{$i}_date"} ?: '—'); ?></td>
        <td><?php echo e(optional($triageForm)->{"tetanus_t{$i}_signature"} ?: '—'); ?></td>
      </tr>
      <?php endfor; ?>
    </tbody>
  </table>

  
  <h4>II. Present Health Problems</h4>
  <ul class="mb-4">
    <?php $__empty_1 = true; $__currentLoopData = $triageForm->present_health_problems ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $problem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <li><?php echo e($problem); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <li class="text-muted">None</li>
    <?php endif; ?>
    <?php if($triageForm->present_problems_other): ?>
      <li><em>Other:</em> <?php echo e($triageForm->present_problems_other); ?></li>
    <?php endif; ?>
  </ul>

  
  <h4>III. Danger Signs</h4>
  <ul class="mb-4">
    <?php $__empty_1 = true; $__currentLoopData = $triageForm->danger_signs ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sign): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <li><?php echo e($sign); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <li class="text-muted">None</li>
    <?php endif; ?>
    <?php if($triageForm->danger_signs_other): ?>
      <li><em>Other:</em> <?php echo e($triageForm->danger_signs_other); ?></li>
    <?php endif; ?>
  </ul>

  
  <h4>IV. OB History</h4>
  <ul class="mb-4">
    <?php $__empty_1 = true; $__currentLoopData = $triageForm->ob_history ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <li><?php echo e($entry); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <li class="text-muted">None recorded</li>
    <?php endif; ?>
  </ul>

  
  <h4>V. Family Planning &amp; PNC</h4>
  <p>
    <strong>Family Planning:</strong> <?php echo e($triageForm->family_planning ?: '—'); ?><br>
    <strong>Previous PNC:</strong> <?php echo e($triageForm->prev_pnc ?: '—'); ?>

  </p>

  
  <h4>VI. Dates &amp; Counts</h4>
  <p>
    <strong>LMP:</strong> <?php echo e($triageForm->lmp ?: '—'); ?><br>
    <strong>EDC:</strong> <?php echo e($triageForm->edc ?: '—'); ?><br>
    <strong>Gravida:</strong> <?php echo e($triageForm->gravida ?? '—'); ?><br>
    <strong>Parity (T/P/A/L):</strong>
      <?php echo e($triageForm->parity_t ?? '—'); ?> /
      <?php echo e($triageForm->parity_p ?? '—'); ?> /
      <?php echo e($triageForm->parity_a ?? '—'); ?> /
      <?php echo e($triageForm->parity_l ?? '—'); ?><br>
    <strong>Age of Gestation (weeks):</strong> <?php echo e($triageForm->aog_weeks ?? '—'); ?>

  </p>

  
  <h4>VII. Physical Exam Log</h4>
  <ul class="mb-4">
    <?php $__empty_1 = true; $__currentLoopData = $triageForm->physical_exam_log ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <li><?php echo e($log); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <li class="text-muted">None recorded</li>
    <?php endif; ?>
  </ul>

  
  <h4>VIII. Delivery &amp; Newborn</h4>
  <p>
    <strong>Prepared By:</strong> <?php echo e($triageForm->prepared_by ?: '—'); ?><br>
    <strong>Blood Type:</strong> <?php echo e($triageForm->blood_type ?: '—'); ?><br>
    <strong>Delivery Type:</strong> <?php echo e($triageForm->delivery_type ?: '—'); ?><br>
    <strong>Birth Weight:</strong> <?php echo e($triageForm->birth_weight ?? '—'); ?> kg<br>
    <strong>Birth Length:</strong> <?php echo e($triageForm->birth_length ?? '—'); ?> cm<br>
    <strong>Apgar Scores:</strong>
    A <?php echo e($triageForm->apgar_appearance ?? '–'); ?>,
    P <?php echo e($triageForm->apgar_pulse ?? '–'); ?>,
    G <?php echo e($triageForm->apgar_grimace ?? '–'); ?>,
    A <?php echo e($triageForm->apgar_activity ?? '–'); ?>,
    R <?php echo e($triageForm->apgar_respiration ?? '–'); ?>

  </p>

  <div class="mt-4">
    <a href="<?php echo e(route('opd_forms.triage.index')); ?>" class="btn btn-secondary">
      ← Back to List
    </a>
    <a href="<?php echo e(route('opd_forms.triage.edit', $triageForm)); ?>" class="btn btn-primary ms-2">
      Edit
    </a>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MAURICIO\Documents\fabel\resources\views/opd_forms/triage/show.blade.php ENDPATH**/ ?>