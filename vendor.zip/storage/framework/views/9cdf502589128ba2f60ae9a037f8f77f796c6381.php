<?php
    $layout = auth()->user()->role === 'encoder'
            ? 'layouts.encoder'
            : 'layouts.admin';

    /** Convenience shortcuts */
    $a     = $submission->answers ?? [];
    $meta  = [
        'Sex'        => ucfirst($a['sex']    ?? '—'),
        'Age'        => $a['age']           ?? '—',
        'Department' => $departmentName     ?: '—',
    ];
    $rows  = $a['followups'] ?? [];
?>



<?php $__env->startSection('content'); ?>
<div class="container py-4">
  
  <div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h3 mb-0">
      <i class="bi bi-journal-text me-2"></i>
      Follow-Up #<?php echo e($submission->id); ?>

    </h1>
    <div class="btn-group">
      <a href="<?php echo e(route('follow-up-opd-forms.index')); ?>" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left-circle me-1"></i> Back
      </a>
      <a href="<?php echo e(route('follow-up-opd-forms.edit', $submission)); ?>" class="btn btn-primary">
        <i class="bi bi-pencil-square me-1"></i> Edit
      </a>
    </div>
  </div>

  
  <div class="card shadow-sm mb-4">
    <div class="card-header bg-primary text-white">Patient Information</div>
    <div class="card-body">
      <div class="row mb-2">
        <div class="col-sm-3 fw-semibold">Name</div>
        <div class="col-sm-9">
          <?php echo e(optional($submission->patient)->name ?? '— Unassigned'); ?>

        </div>
      </div>
      <?php $__currentLoopData = $meta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row mb-2">
          <div class="col-sm-3 fw-semibold"><?php echo e($label); ?></div>
          <div class="col-sm-9"><?php echo e($value); ?></div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="card-footer text-end small text-muted">
      Created: <?php echo e($submission->created_at->format('M d, Y H:i')); ?> &nbsp;|&nbsp;
      Updated: <?php echo e($submission->updated_at->format('M d, Y H:i')); ?>

    </div>
  </div>

  
  <div class="card shadow-sm mb-4">
    <div class="card-header bg-success text-white">Follow-Up Visits</div>
    <div class="card-body p-0">
      <div class="table-responsive">
        <table class="table table-sm table-hover mb-0">
          <thead class="table-light">
            <tr>
              <th>#</th>
              <th>Date</th>
              <th class="text-center">Gest. Weeks</th>
              <th class="text-center">Weight (kg)</th>
              <th class="text-center">BP</th>
              <th>Remarks</th>
            </tr>
          </thead>
          <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <tr>
                <td><?php echo e($i+1); ?></td>
                <td><?php echo e(\Carbon\Carbon::parse($r['date'] ?? null)->format('Y-m-d') ?: '—'); ?></td>
                <td class="text-center"><?php echo e($r['gest_weeks'] ?? '—'); ?></td>
                <td class="text-center"><?php echo e($r['weight']     ?? '—'); ?></td>
                <td class="text-center"><?php echo e($r['bp']         ?? '—'); ?></td>
                <td><?php echo e($r['remarks'] ?? '—'); ?></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <tr>
                <td colspan="6" class="text-center py-4 text-muted">No follow-up entries.</td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  
  <p>
    <button class="btn btn-outline-dark btn-sm" data-bs-toggle="collapse" data-bs-target="#rawJson">
      <i class="bi bi-code-slash me-1"></i> Toggle Raw JSON
    </button>
  </p>
  <div id="rawJson" class="collapse">
    <pre class="p-3 bg-light border rounded">
<?php echo e(json_encode($a, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES)); ?>

    </pre>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MAURICIO\Documents\fabel\resources\views/opd_forms/follow_up/show.blade.php ENDPATH**/ ?>