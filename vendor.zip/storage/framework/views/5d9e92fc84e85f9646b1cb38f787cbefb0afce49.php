


<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('opd_forms.triage._form', [
    'triageForm' => $triageForm,           // null on “create”
    'postRoute'  => route('opd_forms.triage.store'),
    'method'     => 'POST',
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MAURICIO\Documents\fabel\resources\views/opd_forms/triage/create.blade.php ENDPATH**/ ?>