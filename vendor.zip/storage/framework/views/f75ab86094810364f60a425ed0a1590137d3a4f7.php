<?php
    $layout = auth()->user()->role === 'encoder'
            ? 'layouts.encoder'
            : 'layouts.admin';
?>




<?php $__env->startSection('content'); ?>
  <div class="container-fluid">
    <h1 class="mb-4">
      <?php switch($type):
        case ('high_risk'): ?> Add Identification-of-High-Risk Form <?php break; ?>
        <?php case ('follow_up'): ?> Add Follow-Up Records Form <?php break; ?>
        <?php default: ?>           Add OPD-OB Form
      <?php endswitch; ?>
    </h1>

    <?php
      $partial = match($type) {
        'high_risk' => 'high_risk',
        'follow_up' => 'follow_up',
        default     => 'opdb',
      };
    ?>

    <?php echo $__env->make("opd_forms.$partial._form", [
      'opd_form'  => null,
      'postRoute' => route('opd_forms.store'),
      'showButtons' => true,
      'type'      => $type,            
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MAURICIO\Documents\fabel\resources\views/opd_forms/create.blade.php ENDPATH**/ ?>