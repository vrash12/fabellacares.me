

<?php
    // helper to pull old input or existing model data
    if (! function_exists('f')) {
        function f(string $key, $form) {
            return old($key, data_get($form, $key, ''));
        }
    }
?>

<form method="POST" action="<?php echo e($postRoute ?? route('triage.obgyn.store')); ?>">
    <?php echo csrf_field(); ?>

    <div class="text-center mb-4">
        <h2>🩺 OB-GYN TRIAGE FORM</h2>
    </div>

    
    <h5>I. Chief Complaint</h5>
    <div class="mb-3">
        <label class="form-label">Chief Complaint</label>
        <input type="text"
               name="chief_complaint"
               value="<?php echo e(f('chief_complaint', $triageForm)); ?>"
               class="form-control">
    </div>

    
    <h5 class="mt-4">II. Present Illness History</h5>
    <div class="row g-3 mb-3">
        <div class="col-md-6">
            <label class="form-label">Onset of symptoms</label>
            <input type="text"
                   name="onset"
                   value="<?php echo e(f('onset', $triageForm)); ?>"
                   class="form-control">
        </div>
        <div class="col-md-3">
            <label class="form-label">Duration</label>
            <input type="text"
                   name="duration"
                   value="<?php echo e(f('duration', $triageForm)); ?>"
                   class="form-control">
        </div>
        <div class="col-md-3">
            <label class="form-label">Pain scale (0–10)</label>
            <input type="number" min="0" max="10"
                   name="pain_scale"
                   value="<?php echo e(f('pain_scale', $triageForm)); ?>"
                   class="form-control">
        </div>
    </div>

    <div class="row g-3 mb-3">
        <div class="col-md-4">
            <label class="form-label">Description</label>
            <select name="description" class="form-select">
                <option value="">Select…</option>
                <?php $__currentLoopData = ['Sharp','Dull','Cramping','Burning']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($opt); ?>"
                      <?php echo e(f('description',$triageForm)==$opt?'selected':''); ?>>
                        <?php echo e($opt); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>

    <label class="form-label">Associated symptoms</label>
    <div class="row mb-3">
        <?php
            $symps = [
              'Vaginal bleeding','Discharge','Itching','Painful urination',
              'Pelvic pain','Missed period'
            ];
            $checked = f('associated_symptoms',$triageForm) ?: [];
        ?>
        <?php $__currentLoopData = $symps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 form-check">
                <input class="form-check-input"
                       type="checkbox"
                       name="associated_symptoms[]"
                       value="<?php echo e($s); ?>"
                       <?php echo e(in_array($s,$checked)?'checked':''); ?>>
                <label class="form-check-label"><?php echo e($s); ?></label>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-6 mt-2">
            <label class="form-label">Others</label>
            <input type="text"
                   name="associated_symptoms_other"
                   value="<?php echo e(f('associated_symptoms_other',$triageForm)); ?>"
                   class="form-control">
        </div>
    </div>

    
    <h5 class="mt-4">III. Menstrual History</h5>
    <div class="row g-3 mb-3">
        <div class="col-md-3">
            <label class="form-label">Age of menarche</label>
            <input type="number" min="0"
                   name="menarche_age"
                   value="<?php echo e(f('menarche_age',$triageForm)); ?>"
                   class="form-control">
        </div>
        <div class="col-md-3">
            <label class="form-label">Cycle (days)</label>
            <input type="number" min="0"
                   name="cycle_length"
                   value="<?php echo e(f('cycle_length',$triageForm)); ?>"
                   class="form-control">
        </div>
        <div class="col-md-3">
            <label class="form-label">Flow</label>
            <select name="flow" class="form-select">
                <option value="">Select…</option>
                <?php $__currentLoopData = ['Light','Moderate','Heavy']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($opt); ?>"
                      <?php echo e(f('flow',$triageForm)==$opt?'selected':''); ?>>
                        <?php echo e($opt); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-3">
            <label class="form-label">LMP</label>
            <input type="date"
                   name="lmp"
                   value="<?php echo e(f('lmp',$triageForm)); ?>"
                   class="form-control">
        </div>
    </div>

    <label class="form-label">Menstrual concerns</label>
    <div class="mb-3 row">
        <?php
           $concerns = ['Dysmenorrhea','Irregular cycle','Amenorrhea'];
        ?>
        <?php $__currentLoopData = $concerns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 form-check">
                <input class="form-check-input"
                       type="checkbox"
                       name="menstrual_concerns[]"
                       value="<?php echo e($c); ?>"
                       <?php echo e(in_array($c, f('menstrual_concerns',$triageForm)?:[]) ? 'checked':''); ?>>
                <label class="form-check-label"><?php echo e($c); ?></label>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    
    <h5 class="mt-4">IV. Obstetric History</h5>
    <div class="row g-3 mb-3">
        <div class="col-md-2">
            <label class="form-label">Gravida</label>
            <input type="number" min="0"
                   name="gravida"
                   value="<?php echo e(f('gravida',$triageForm)); ?>"
                   class="form-control">
        </div>
        <div class="col-md-2">
            <label class="form-label">Para</label>
            <input type="number" min="0"
                   name="para"
                   value="<?php echo e(f('para',$triageForm)); ?>"
                   class="form-control">
        </div>
        <div class="col-md-2">
            <label class="form-label">Full-term</label>
            <input type="number" min="0"
                   name="full_term"
                   value="<?php echo e(f('full_term',$triageForm)); ?>"
                   class="form-control">
        </div>
        <div class="col-md-2">
            <label class="form-label">Preterm</label>
            <input type="number" min="0"
                   name="preterm"
                   value="<?php echo e(f('preterm',$triageForm)); ?>"
                   class="form-control">
        </div>
        <div class="col-md-2">
            <label class="form-label">Abortion</label>
            <input type="number" min="0"
                   name="abortion"
                   value="<?php echo e(f('abortion',$triageForm)); ?>"
                   class="form-control">
        </div>
        <div class="col-md-2">
            <label class="form-label">Living</label>
            <input type="number" min="0"
                   name="living"
                   value="<?php echo e(f('living',$triageForm)); ?>"
                   class="form-control">
        </div>
    </div>

    <div class="row g-3 mb-3">
        <div class="col-md-6">
            <label class="form-label">Previous pregnancies</label>
            <select name="prev_pregnancy_type" class="form-select">
                <option value="">Select…</option>
                <?php $__currentLoopData = ['Normal','Cesarean','Complicated']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($opt); ?>"
                    <?php echo e(f('prev_pregnancy_type',$triageForm)==$opt?'selected':''); ?>>
                    <?php echo e($opt); ?>

                  </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-3">
            <label class="form-label">Current pregnancy?</label>
            <select name="current_pregnancy" class="form-select">
                <option value="">Select…</option>
                <?php $__currentLoopData = ['Yes','No']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($opt); ?>"
                    <?php echo e(f('current_pregnancy',$triageForm)==$opt?'selected':''); ?>>
                    <?php echo e($opt); ?>

                  </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-3">
            <label class="form-label">If yes, weeks gestation</label>
            <input type="number" min="0"
                   name="gestation_weeks"
                   value="<?php echo e(f('gestation_weeks',$triageForm)); ?>"
                   class="form-control">
        </div>
    </div>

    <div class="row g-3 mb-3">
        <div class="col-md-4">
            <label class="form-label">Prenatal checkups done?</label>
            <select name="prenatal_done" class="form-select">
                <option value="">Select…</option>
                <?php $__currentLoopData = ['Yes','No']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($opt); ?>"
                    <?php echo e(f('prenatal_done',$triageForm)==$opt?'selected':''); ?>>
                    <?php echo e($opt); ?>

                  </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-4">
            <label class="form-label">Danger signs?</label>
            <select name="danger_signs_present" class="form-select">
                <option value="">Select…</option>
                <?php $__currentLoopData = ['Yes','No']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($opt); ?>"
                    <?php echo e(f('danger_signs_present',$triageForm)==$opt?'selected':''); ?>>
                    <?php echo e($opt); ?>

                  </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-4">
            <label class="form-label">If yes, specify</label>
            <input type="text"
                   name="danger_signs_details"
                   value="<?php echo e(f('danger_signs_details',$triageForm)); ?>"
                   class="form-control">
        </div>
    </div>

    
    <h5 class="mt-4">V. Gynecologic History</h5>
    <div class="row g-3 mb-3">
        <div class="col-md-6">
            <label class="form-label">Pap smear history</label>
            <div class="input-group">
              <select name="pap_smear_done" class="form-select">
                  <option value="">Select…</option>
                  <?php $__currentLoopData = ['Yes','No']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($opt); ?>"
                      <?php echo e(f('pap_smear_done',$triageForm)==$opt?'selected':''); ?>>
                      <?php echo e($opt); ?>

                    </option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
              <input type="date"
                     name="pap_smear_date"
                     value="<?php echo e(f('pap_smear_date',$triageForm)); ?>"
                     class="form-control">
            </div>
        </div>
        <div class="col-md-6">
            <label class="form-label">History of STIs</label>
            <select name="sti_history" class="form-select">
                <option value="">Select…</option>
                <?php $__currentLoopData = ['Yes','No']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($opt); ?>"
                    <?php echo e(f('sti_history',$triageForm)==$opt?'selected':''); ?>>
                    <?php echo e($opt); ?>

                  </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>

    <div class="mb-3">
        <label class="form-label">Contraceptive use</label>
        <select name="contraceptive_use" class="form-select">
            <option value="">Select…</option>
            <?php $__currentLoopData = ['Pills','IUD','Injectables','Condom','None']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($opt); ?>"
                <?php echo e(f('contraceptive_use',$triageForm)==$opt?'selected':''); ?>>
                <?php echo e($opt); ?>

              </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    
    <h5 class="mt-4">VI. Vital Signs</h5>
    <div class="row g-3 mb-4">
      <div class="col-md-3">
        <label class="form-label">BP (mmHg)</label>
        <div class="input-group">
          <input type="number" name="bp_systolic" value="<?php echo e(f('bp_systolic',$triageForm)); ?>" class="form-control" placeholder="Systolic">
          <span class="input-group-text">/</span>
          <input type="number" name="bp_diastolic" value="<?php echo e(f('bp_diastolic',$triageForm)); ?>" class="form-control" placeholder="Diastolic">
        </div>
      </div>
      <div class="col-md-2">
        <label class="form-label">HR (bpm)</label>
        <input type="number" name="heart_rate" value="<?php echo e(f('heart_rate',$triageForm)); ?>" class="form-control">
      </div>
      <div class="col-md-2">
        <label class="form-label">RR (cpm)</label>
        <input type="number" name="resp_rate" value="<?php echo e(f('resp_rate',$triageForm)); ?>" class="form-control">
      </div>
      <div class="col-md-2">
        <label class="form-label">Temp (°C)</label>
        <input type="number" step="0.1" name="temperature" value="<?php echo e(f('temperature',$triageForm)); ?>" class="form-control">
      </div>
      <div class="col-md-1">
        <label class="form-label">Height (cm)</label>
        <input type="number" name="height" value="<?php echo e(f('height',$triageForm)); ?>" class="form-control">
      </div>
      <div class="col-md-1">
        <label class="form-label">Weight (kg)</label>
        <input type="number" name="weight" value="<?php echo e(f('weight',$triageForm)); ?>" class="form-control">
      </div>
    </div>

    <button type="submit" class="btn btn-primary">
      <?php echo e(isset($triageForm) ? 'Update Form' : 'Save Form'); ?>

    </button>
</form>
<?php /**PATH C:\Users\MAURICIO\Documents\fabel\resources\views/opd_forms/obgyn_triage/_form.blade.php ENDPATH**/ ?>