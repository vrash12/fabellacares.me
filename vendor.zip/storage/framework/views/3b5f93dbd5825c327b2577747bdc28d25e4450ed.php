<?php $__env->startSection('content'); ?>
<div class="container-xl">

  
  <div class="alert alert-info d-flex align-items-center mb-4 shadow-sm">
    <i class="bi bi-graph-up-arrow me-2 fs-4"></i>
    <div class="flex-grow-1">
      <strong>Patient Trend Analysis</strong> helps you anticipate OPD load,
      optimise staffing, and minimise patient waiting time.
      Choose a date-range, department, and forecasting model – then click
      <em>Generate New</em> for an updated prediction.
    </div>
  </div>

  
  
  <?php
    /* keep { $from, $to, $department, $model, $steps, $windowSize, $queues } from
       your controller exactly as before */
  ?>
  <form class="row gy-2 gx-3 align-items-end mb-4" method="GET" action="<?php echo e(route('trends.index')); ?>">
    <div class="col-lg-2 col-md-3">
      <label class="form-label mb-0">From
        <i class="bi bi-question-circle text-muted" data-bs-toggle="tooltip"
           title="Earliest date of historical data to include"></i>
      </label>
      <input type="date" name="from" class="form-control"
             value="<?php echo e($from); ?>" max="<?php echo e(now()->format('Y-m-d')); ?>">
    </div>

    <div class="col-lg-2 col-md-3">
      <label class="form-label mb-0">To
        <i class="bi bi-question-circle text-muted" data-bs-toggle="tooltip"
           title="Latest date of historical data to include"></i>
      </label>
      <input type="date" name="to" class="form-control"
             value="<?php echo e($to); ?>" max="<?php echo e(now()->format('Y-m-d')); ?>">
    </div>

    <div class="col-lg-3 col-md-4">
      <label class="form-label mb-0">Department
        <i class="bi bi-question-circle text-muted" data-bs-toggle="tooltip"
           title="Filter visits belonging to one department / queue"></i>
      </label>
      <select name="department" class="form-select">
        <option value="">All Departments</option>
        <?php $__currentLoopData = $queues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($q->id); ?>" <?php echo e((string)$q->id===(string)$department?'selected':''); ?>>
            <?php echo e($q->name); ?>

          </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>

    <div class="col-lg-2 col-md-4">
      <label class="form-label mb-0">Model
        <i class="bi bi-question-circle text-muted" data-bs-toggle="tooltip"
           title="ARIMA = statistical · LSTM = neural-net · Ensemble = average"></i>
      </label>
      <select name="model" class="form-select">
        <option value="ensemble" <?php echo e($model==='ensemble'?'selected':''); ?>>Ensemble</option>
        <option value="arima"    <?php echo e($model==='arima'   ?'selected':''); ?>>ARIMA</option>
        <option value="lstm"     <?php echo e($model==='lstm'    ?'selected':''); ?>>LSTM</option>
      </select>
    </div>

    <div class="col-lg-1 col-md-2">
      <label class="form-label mb-0">Days
        <i class="bi bi-question-circle text-muted" data-bs-toggle="tooltip"
           title="How many days into the future to predict"></i>
      </label>
      <select name="steps" class="form-select">
        <option value="7"  <?php echo e($steps==7  ?'selected':''); ?>>7</option>
        <option value="14" <?php echo e($steps==14 ?'selected':''); ?>>14</option>
        <option value="30" <?php echo e($steps==30 ?'selected':''); ?>>30</option>
      </select>
    </div>

    
    <div class="col-lg-1 col-md-2" id="lstm-window-col">
      <label class="form-label mb-0">Window
        <i class="bi bi-question-circle text-muted" data-bs-toggle="tooltip"
           title="Number of past days LSTM looks at as one sample"></i>
      </label>
      <select name="window_size" class="form-select">
        <option value="14" <?php echo e($windowSize==14?'selected':''); ?>>14</option>
        <option value="21" <?php echo e($windowSize==21?'selected':''); ?>>21</option>
        <option value="30" <?php echo e($windowSize==30?'selected':''); ?>>30</option>
      </select>
    </div>

    <div class="col-auto text-end mt-2 mt-md-0">
      <button class="btn btn-primary me-2"><i class="bi bi-funnel"></i> Apply</button>

      <button
        formaction="<?php echo e(route('trends.request')); ?>"
        formmethod="POST"
        class="btn btn-outline-secondary position-relative">
        <?php echo csrf_field(); ?>
        <i class="bi bi-arrow-repeat"></i> Generate New
        <?php if(! empty($trend?->cached)): ?>
          <span class="position-absolute top-0 start-100 translate-middle badge bg-warning text-dark">
            cached
          </span>
        <?php endif; ?>
      </button>
    </div>
  </form>

  <div class="row">
    
    <div class="col-lg-9">

      
      <?php
        $hist = $trend['historical_mean'] ?? null;
        $next = $trend[$model]['values'][0] ?? null;
        $delta = ($hist && $next) ? $next - $hist : null;
      ?>
      <div class="row g-3 mb-4">
        <div class="col-md-6">
          <div class="card text-center shadow-sm h-100">
            <div class="card-body"><h6 class="text-muted mb-1">Historical Mean</h6>
              <h2 class="fw-bold mb-0"><?php echo e($hist ?? '—'); ?></h2></div>
          </div>
        </div>
        <div class="col-md-6">
          <div class="card text-center shadow-sm h-100">
            <div class="card-body"><h6 class="text-muted mb-1"><?php echo e(strtoupper($model)); ?> Next Day</h6>
              <h2 class="fw-bold mb-0">
                <?php echo e($next ?? '—'); ?>

                <?php if($delta!==null): ?>
                  <span class="badge <?php echo e($delta>=0?'bg-danger':'bg-success'); ?> ms-2">
                    <?php echo e($delta>=0?'+':''); ?><?php echo e(number_format($delta,0)); ?>

                  </span>
                <?php endif; ?>
              </h2>
            </div>
          </div>
        </div>
      </div>

      
      <?php
        $dept = optional($queues->firstWhere('id',$department))->name ?? null;

        /** ARIMA rules **/
        $rulesArima = [
          'all' => [
            [20,'gte','Increase staffing (2 extra doctors)','bg-danger text-white'],
            [ 5,'gte','Monitor queue & prepare relief staff','bg-warning'],
            [-5,'lte','Normal staffing adequate','bg-success text-white'],
          ],
          'OB' => [
            [15,'gte','Add 1 OB resident to OPD','bg-danger text-white'],
            [ 5,'gte','Prepare standby staff','bg-warning'],
            [-5,'lte','Current staffing OK','bg-success text-white'],
          ],
        ];

        /** LSTM rules (percentage-based) **/
        $rulesLstm = [
          'all' => [
            [0.30,'abs','High volatility – double-check resources','bg-danger text-white'],
            [0.15,'abs','Moderate change – flag for review','bg-warning'],
            [0.00,'abs','Stable – proceed with usual roster','bg-success text-white'],
          ],
        ];

        /** Ensemble rules – simply reuse ARIMA style (absolute delta) **/
        $rulesEns = [
          'all' => [
            [15,'abs','Large swing – review both ARIMA & LSTM','bg-danger text-white'],
            [ 8,'abs','Medium swing – watch tomorrow','bg-warning'],
            [ 0,'abs','Forecasts in agreement – normal ops','bg-success text-white'],
          ],
        ];
      ?>

      
      <?php if(in_array($model,['arima','ensemble']) && $hist && $next): ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.trends.guidance','data' => ['title' => 'ARIMA Guidelines','rules' => $rulesArima[$dept] ?? $rulesArima['all'],'delta' => $delta]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('trends.guidance'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'ARIMA Guidelines','rules' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($rulesArima[$dept] ?? $rulesArima['all']),'delta' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($delta)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
      <?php endif; ?>

      
      <?php if(in_array($model,['lstm','ensemble']) && $hist && $next): ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.trends.guidance','data' => ['title' => 'LSTM Guidelines','subtitle' => '(based on % change vs historical mean)','rules' => $rulesLstm['all'],'delta' => $delta / max(1,$hist),'percent' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('trends.guidance'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'LSTM Guidelines','subtitle' => '(based on % change vs historical mean)','rules' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($rulesLstm['all']),'delta' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($delta / max(1,$hist)),'percent' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
      <?php endif; ?>

      
      <?php if($model==='ensemble' && $hist && $next): ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.trends.guidance','data' => ['title' => 'Ensemble Guidelines','rules' => $rulesEns['all'],'delta' => $delta]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('trends.guidance'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Ensemble Guidelines','rules' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($rulesEns['all']),'delta' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($delta)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
      <?php endif; ?>

      
      <?php if(isset($trend)): ?>
        <?php switch($model):
          case ('arima'): ?>
            <?php echo $__env->renderWhen(isset($trend['arima']),
              'trends.partials.arima',
              ['from'=>$from,'to'=>$to,'steps'=>$steps,'trend'=>$trend], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
            <?php break; ?>

          <?php case ('lstm'): ?>
            <?php echo $__env->renderWhen(isset($trend['lstm']),
              'trends.partials.lstm',
              ['from'=>$from,'to'=>$to,'steps'=>$steps,'windowSize'=>$windowSize,'trend'=>$trend], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
            <?php break; ?>

          <?php case ('ensemble'): ?>
            <?php echo $__env->renderWhen(isset($trend['ensemble']),
              'trends.partials.ensemble',
              ['from'=>$from,'to'=>$to,'steps'=>$steps,'windowSize'=>$windowSize,'trend'=>$trend], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
            <?php break; ?>
        <?php endswitch; ?>
      <?php endif; ?>
    </div>

    
    <div class="col-lg-3">
      <div class="card shadow-sm sticky-top" style="top:80px;">
        <div class="card-header bg-light d-flex justify-content-between align-items-center">
          <span><i class="bi bi-lightbulb me-1 text-warning"></i> Quick Guide</span>
          <button class="btn btn-sm btn-outline-secondary" data-bs-toggle="collapse"
                  data-bs-target="#helpCollapse"><i class="bi bi-chevron-down"></i></button>
        </div>
        <div class="collapse show" id="helpCollapse">
          <div class="card-body small">
            <h6 class="fw-bold text-primary mb-1">ARIMA</h6>
            <p class="mb-1">Classic statistical model; great for seasonal trends.</p>
            <h6 class="fw-bold text-success mt-3 mb-1">LSTM</h6>
            <p class="mb-1">Neural network catches complex patterns & sudden spikes.</p>
            <h6 class="fw-bold text-info mt-3 mb-1">Ensemble</h6>
            <p class="mb-0">Averaging ARIMA & LSTM typically gives the safest forecast.</p>
          </div>
        </div>
      </div>
    </div>
  </div>

  
  <div class="d-flex justify-content-end mt-4">
    <div class="btn-group">
      <button class="btn btn-outline-success dropdown-toggle" data-bs-toggle="dropdown">
        <i class="bi bi-download me-1"></i> Export
      </button>
      <ul class="dropdown-menu dropdown-menu-end">
        <li><a class="dropdown-item" href="<?php echo e(route('trends.excel', [
              'from'=>$from,'to'=>$to,'model'=>$model,'department'=>$department,
              'steps'=>$steps,'window_size'=>$windowSize ])); ?>">
              <i class="bi bi-file-earmark-spreadsheet me-1 text-success"></i> Excel
            </a></li>
        <li><a class="dropdown-item" href="<?php echo e(route('trends.pdf', [
              'from'=>$from,'to'=>$to,'model'=>$model,'department'=>$department,
              'steps'=>$steps,'window_size'=>$windowSize ])); ?>">
              <i class="bi bi-file-earmark-pdf me-1 text-danger"></i> PDF
            </a></li>
      </ul>
    </div>
  </div>

</div> 
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
(function () {
  const modelSel = document.querySelector('select[name=model]');
  const winCol   = document.getElementById('lstm-window-col');
  const toggle   = () => winCol.classList.toggle('d-none', modelSel.value !== 'lstm');
  toggle(); modelSel.addEventListener('change', toggle);
  new bootstrap.Tooltip(document.body, { selector:'[data-bs-toggle="tooltip"]' });
})();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MAURICIO\Documents\fabel\resources\views/trends/index.blade.php ENDPATH**/ ?>