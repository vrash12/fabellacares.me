<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Served-Token History</title>
  <style>
    body { font-family: sans-serif; font-size: 11px; }
    h2   { margin-bottom: .4em; }
    table { width: 100%; border-collapse: collapse; }
    th,td { border: 1px solid #000; padding: 4px; }
  </style>
</head>
<body>
  <h2>Served-Token History</h2>
  <p>From: <?php echo e($from); ?>  To: <?php echo e($to); ?></p>

  <table>
    <thead>
      <tr>
        <th>Department</th>
        <th>Token</th>
        <th>Served At</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $tokens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($t->department); ?></td>
          <td><?php echo e($t->code); ?></td>
          <td><?php echo e($t->served_at); ?></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</body>
</html>
<?php /**PATH C:\Users\MAURICIO\Documents\fabel\resources\views/reports/tokens_pdf.blade.php ENDPATH**/ ?>