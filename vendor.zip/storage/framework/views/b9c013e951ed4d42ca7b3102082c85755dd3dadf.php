
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
  'title',
  'subtitle' => '',
  'rules',    // array of [threshold, comparator, label, css-class]
  'delta',    // numeric delta (or % delta if percent=true)
  'percent' => false,
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
  'title',
  'subtitle' => '',
  'rules',    // array of [threshold, comparator, label, css-class]
  'delta',    // numeric delta (or % delta if percent=true)
  'percent' => false,
]); ?>
<?php foreach (array_filter(([
  'title',
  'subtitle' => '',
  'rules',    // array of [threshold, comparator, label, css-class]
  'delta',    // numeric delta (or % delta if percent=true)
  'percent' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php
  // Format helper
  $fmt = fn($v) => $percent
    ? number_format($v * 100, 1) . ' %' 
    : number_format($v, 0);

  // Rule‐matching helper
  $test = function($rule) use ($delta, $percent) {
    [$thr, $cmp] = $rule;
    if ($delta === null) return false;
    $val = $percent ? abs($delta) : $delta;
    switch ($cmp) {
      case 'gte': return $val >= $thr;
      case 'gt':  return $val >  $thr;
      case 'lte': return $val <= $thr;
      case 'lt':  return $val <  $thr;
      case 'abs': return $val >= $thr; // always absolute
    }
    return false;
  };
?>

<div class="card mb-4 shadow-sm">
  <div class="card-header bg-light">
    <i class="bi bi-flag me-1"></i> <?php echo e($title); ?>

    <?php if($subtitle): ?>
      <small class="text-muted"> <?php echo e($subtitle); ?> </small>
    <?php endif; ?>
  </div>
  <div class="card-body p-0">
    <table class="table mb-0">
      <thead class="table-light">
        <tr>
          <th style="width:140px;">Threshold</th>
          <th>Recommended Action</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $rules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php
            [$thr, $cmp, $label, $cls] = $r;
          ?>
          <tr class="<?php echo e($test($r) ? $cls : ''); ?>">
            <td class="text-center">
              <?php if($cmp === 'abs'): ?>
                ± <?php echo e($fmt($thr)); ?>

              <?php else: ?>
                <?php echo e($cmp === 'gte' || $cmp === 'gt' ? '≥' : '≤'); ?>

                <?php echo e($fmt($thr)); ?>

              <?php endif; ?>
            </td>
            <td><?php echo e($label); ?></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
</div>
<?php /**PATH C:\Users\MAURICIO\Documents\fabel\resources\views/components/trends/guidance.blade.php ENDPATH**/ ?>