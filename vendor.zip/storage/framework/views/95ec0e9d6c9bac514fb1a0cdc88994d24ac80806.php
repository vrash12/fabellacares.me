

<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('opd_forms.obgyn_triage._form', [
    'triageForm' => $triageForm ?? null,
    'postRoute'  => isset($triageForm)
                     ? route('triage.obgyn.update', $triageForm)
                     : route('triage.obgyn.store')
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MAURICIO\Documents\fabel\resources\views/opd_forms/obgyn_triage/create.blade.php ENDPATH**/ ?>