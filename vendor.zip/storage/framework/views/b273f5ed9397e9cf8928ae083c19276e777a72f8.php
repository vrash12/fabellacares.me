<?php $__env->startSection('content'); ?>
<div class="container col-lg-6">
  <h2>Edit Schedule</h2>
  <form action="<?php echo e(route('schedules.update',$schedule)); ?>" method="POST">
    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
    <?php echo $__env->make('schedules._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <button class="btn btn-info mt-3">Update</button>
    <a href="<?php echo e(route('schedules.index')); ?>" class="btn btn-secondary mt-3">Cancel</a>
  </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MAURICIO\Documents\fabel\resources\views/schedules/edit.blade.php ENDPATH**/ ?>