
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Token <?php echo e($token->code); ?></title>

<style>
/* ---------- 1.   physical size & zero margin --------------------------- */
@media print {
    @page { size: 76mm 130mm; margin: 0; }
}
html,body      { width: 76mm; margin:0; font-family: Arial, sans-serif; }
body           { display:flex; flex-direction:column; align-items:center;
                 justify-content:center; text-align:center; padding:8mm 4mm; }

/* ---------- 2.   simple branding -------------------------------------- */
.logo          { width:30mm; margin-bottom:6mm; }
.dept          { font-size:16pt; font-weight:bold; margin-bottom:3mm; }
.code          { font-size:46pt; font-weight:900; letter-spacing:2px;
                 margin:6mm 0; }
.time          { font-size:10pt; color:#555; }
hr             { width:100%; border:none; border-top:1px dashed #000;
                 margin:6mm 0; }
.patient       { font-size:14pt; font-weight:600; margin:3mm 0; }
</style>
</head>
<body onload="window.print(); setTimeout(()=>window.close(),400);">
  <img src="<?php echo e(asset('images/fabella-logo.png')); ?>" class="logo" alt="Logo">
  <div class="dept"><?php echo e($token->queue->name); ?></div>
  <hr>

  <div class="code"><?php echo e($token->code); ?></div>

  <?php if(! empty($patientName)): ?>
    <div class="patient"><?php echo e($patientName); ?></div>
  <?php endif; ?>

  <hr>
   <div class="time" id="printTime"></div>

  <script>
    document.addEventListener('DOMContentLoaded', () => {
      const opts = {
        year:   'numeric',
        month:  'long',
        day:    'numeric',
        hour:   'numeric',
        minute: 'numeric',
        hour12: true
      };
      document.getElementById('printTime')
              .innerText = new Date().toLocaleString(undefined, opts);
      // trigger print after the timestamp is set
      window.print();
      setTimeout(()=>window.close(), 400);
    });
  </script>

</body>
</html>
<?php /**PATH C:\Users\MAURICIO\Documents\fabel\resources\views/queue/print.blade.php ENDPATH**/ ?>