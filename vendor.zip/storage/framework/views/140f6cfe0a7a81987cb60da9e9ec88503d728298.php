<?php
    $layout = auth()->user()->role === 'encoder'
            ? 'layouts.encoder'
            : 'layouts.admin';
?>



<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
  
  <div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h3 mb-0">
      <i class="bi bi-journal-medical me-2"></i>
      OPD Follow-Up Submissions
    </h1>
    <a href="<?php echo e(route('follow-up-opd-forms.create')); ?>" class="btn btn-success">
      <i class="bi bi-plus-lg me-1"></i> New Follow-Up
    </a>
  </div>

  
  <?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
      <i class="bi bi-check-circle-fill me-2"></i>
      <?php echo e(session('success')); ?>

      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
  <?php endif; ?>

  <div class="card shadow-sm">
    <div class="card-body p-0">
      <div class="table-responsive">
        <table class="table table-striped align-middle mb-0">
          <thead class="table-light">
            <tr class="text-center">
              <th style="width: 50px;">#</th>
              <th>Patient</th>
            
              <th>Date Created</th>
              <th style="width: 180px;">Actions</th>
            </tr>
          </thead>
          <tbody>
          <?php $__empty_1 = true; $__currentLoopData = $submissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $submission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
  <tr class="text-center">
    <td><?php echo e($idx + 1); ?></td>
    <td class="text-start">
      <?php echo e(optional($submission->patient)->name ?? '—'); ?>

    </td>
  
    <td><?php echo e($submission->created_at->format('Y-m-d H:i')); ?></td>
    <td>
      <div class="d-flex justify-content-center gap-1">
        <a href="<?php echo e(route('follow-up-opd-forms.show', $submission)); ?>" class="btn btn-sm btn-primary">
          <i class="bi bi-eye"></i>
        </a>
        <form action="<?php echo e(route('follow-up-opd-forms.destroy', $submission)); ?>" method="POST"
              onsubmit="return confirm('Are you sure?');">
          <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
          <button type="submit" class="btn btn-sm btn-danger"><i class="bi bi-trash"></i></button>
        </form>
      </div>
    </td>
  </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
  <tr>
    <td colspan="5" class="text-center text-muted py-4">
      No follow-up records found.
    </td>
  </tr>
<?php endif; ?>

          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MAURICIO\Documents\fabel\resources\views/opd_forms/follow_up/index.blade.php ENDPATH**/ ?>