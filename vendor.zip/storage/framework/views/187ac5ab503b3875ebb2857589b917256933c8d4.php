

<?php
    if (! function_exists('f')) {
        function f(string $key, $form) {
            return old($key, data_get($form, $key, ''));
        }
    }
?>

<form method="POST" action="<?php echo e($postRoute ?? route('triage.pedia.store')); ?>">
  <?php echo csrf_field(); ?>

  <div class="text-center mb-4">
    <h2>🧸 PEDIA FORM</h2>
  </div>

  
  <h5>I. Chief Complaint</h5>
  <div class="row g-3 mb-3">
    <div class="col-md-6">
      <label class="form-label">Main Concern</label>
      <input type="text"
             name="main_concern"
             value="<?php echo e(f('main_concern',$pediaForm)); ?>"
             class="form-control">
    </div>
    <div class="col-md-3">
      <label class="form-label">Date Started</label>
      <input type="date"
             name="date_started"
             value="<?php echo e(f('date_started',$pediaForm)); ?>"
             class="form-control">
    </div>
    <div class="col-md-3">
      <label class="form-label">Progression</label>
      <select name="progression" class="form-select">
        <option value="">Select…</option>
        <?php $__currentLoopData = ['Improving','Worsening','Same']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($opt); ?>"
            <?php echo e(f('progression',$pediaForm)==$opt?'selected':''); ?>>
            <?php echo e($opt); ?>

          </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>
  </div>

  <div class="mb-4">
    <label class="form-label d-block">Associated Symptoms</label>
    <?php $__currentLoopData = [
        'Fever','Cough','Colds','Vomiting','Diarrhea',
        'Rash','Seizures','Ear Pain','Eye Discharge','Breathing Difficulty'
      ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sym): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="form-check form-check-inline">
        <input class="form-check-input" type="checkbox"
               name="assoc_symptoms[]" value="<?php echo e($sym); ?>"
               <?php echo e(in_array($sym, f('assoc_symptoms',$pediaForm)?:[]) ? 'checked':''); ?>>
        <label class="form-check-label"><?php echo e($sym); ?></label>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <input type="text"
           name="assoc_symptoms_other"
           value="<?php echo e(f('assoc_symptoms_other',$pediaForm)); ?>"
           class="form-control mt-2"
           placeholder="Others">
  </div>

  
  <h5 class="mt-4">II. Birth & Neonatal History</h5>
  <div class="row g-3 mb-3">
    <div class="col-md-4">
      <label class="form-label">Type of Delivery</label>
      <select name="delivery_type" class="form-select">
        <option value="">Select…</option>
        <?php $__currentLoopData = ['Normal Spontaneous','CS','Instrumental']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($opt); ?>"
            <?php echo e(f('delivery_type',$pediaForm)==$opt?'selected':''); ?>>
            <?php echo e($opt); ?>

          </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>
    <div class="col-md-4">
      <label class="form-label">Place of Delivery</label>
      <input type="text"
             name="delivery_place"
             value="<?php echo e(f('delivery_place',$pediaForm)); ?>"
             class="form-control">
    </div>
    <div class="col-md-2">
      <label class="form-label">Birth Weight (kg)</label>
      <input type="number" step="0.01"
             name="birth_weight"
             value="<?php echo e(f('birth_weight',$pediaForm)); ?>"
             class="form-control">
    </div>
    <div class="col-md-2">
      <label class="form-label">Term</label>
      <select name="term" class="form-select">
        <option value="">Select…</option>
        <?php $__currentLoopData = ['Full Term','Preterm']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($opt); ?>"
            <?php echo e(f('term',$pediaForm)==$opt?'selected':''); ?>>
            <?php echo e($opt); ?>

          </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>
  </div>

  <div class="row g-3 mb-4">
    <div class="col-md-4">
      <label class="form-label">NICU Admission</label>
      <select name="nicu_admission" class="form-select">
        <option value="">Select…</option>
        <?php $__currentLoopData = ['Yes','No']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($opt); ?>"
            <?php echo e(f('nicu_admission',$pediaForm)==$opt?'selected':''); ?>>
            <?php echo e($opt); ?>

          </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>
    <div class="col-md-8">
      <label class="form-label">If Yes, Reason</label>
      <input type="text"
             name="nicu_reason"
             value="<?php echo e(f('nicu_reason',$pediaForm)); ?>"
             class="form-control">
    </div>
  </div>

  
  <h5 class="mt-4">III. Immunization History</h5>
  <div class="row g-3 mb-4">
    <div class="col-md-4">
      <label class="form-label">Status</label>
      <select name="immunization_status" class="form-select">
        <option value="">Select…</option>
        <?php $__currentLoopData = ['Fully Immunized','Incomplete','Unknown']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($opt); ?>"
            <?php echo e(f('immunization_status',$pediaForm)==$opt?'selected':''); ?>>
            <?php echo e($opt); ?>

          </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>
    <div class="col-md-4">
      <label class="form-label">Missed Vaccines</label>
      <input type="text"
             name="missed_vaccines"
             value="<?php echo e(f('missed_vaccines',$pediaForm)); ?>"
             class="form-control">
    </div>
    <div class="col-md-4">
      <label class="form-label">Last Vaccine & Date</label>
      <div class="input-group">
        <input type="text"
               name="last_vaccine"
               value="<?php echo e(f('last_vaccine',$pediaForm)); ?>"
               class="form-control"
               placeholder="Name">
        <input type="date"
               name="last_vaccine_date"
               value="<?php echo e(f('last_vaccine_date',$pediaForm)); ?>"
               class="form-control">
      </div>
    </div>
  </div>

  
  <h5 class="mt-4">IV. Nutritional Status</h5>
  <div class="row g-3 mb-4">
    <div class="col-md-4">
      <label class="form-label">Current Feeding</label>
      <select name="feeding_type" class="form-select">
        <option value="">Select…</option>
        <?php $__currentLoopData = ['Breastfed','Formula','Mixed']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($opt); ?>"
            <?php echo e(f('feeding_type',$pediaForm)==$opt?'selected':''); ?>>
            <?php echo e($opt); ?>

          </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>
    <div class="col-md-4">
      <label class="form-label">Solid Foods Introduced</label>
      <select name="solids_introduced" class="form-select">
        <option value="">Select…</option>
        <?php $__currentLoopData = ['Yes','No']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($opt); ?>"
            <?php echo e(f('solids_introduced',$pediaForm)==$opt?'selected':''); ?>>
            <?php echo e($opt); ?>

          </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>
    <div class="col-md-2">
      <label class="form-label">At Age (mo)</label>
      <input type="number"
             name="solids_age"
             value="<?php echo e(f('solids_age',$pediaForm)); ?>"
             class="form-control">
    </div>
    <div class="col-md-1">
      <label class="form-label">Appetite</label>
      <select name="appetite" class="form-select">
        <option value="">Select…</option>
        <?php $__currentLoopData = ['Good','Poor']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($opt); ?>"
            <?php echo e(f('appetite',$pediaForm)==$opt?'selected':''); ?>>
            <?php echo e($opt); ?>

          </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>
    <div class="col-md-1">
      <label class="form-label">Weight Gain</label>
      <select name="weight_gain" class="form-select">
        <option value="">Select…</option>
        <?php $__currentLoopData = ['Normal','Not gaining']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($opt); ?>"
            <?php echo e(f('weight_gain',$pediaForm)==$opt?'selected':''); ?>>
            <?php echo e($opt); ?>

          </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>
  </div>
  <div class="mb-4">
    <label class="form-label">24-hour Diet Recall</label>
    <input type="text"
           name="diet_recall"
           value="<?php echo e(f('diet_recall',$pediaForm)); ?>"
           class="form-control">
  </div>

  
  <h5 class="mt-4">V. Vital Signs</h5>
  <div class="row g-3 mb-4">
    <div class="col-md-3">
      <label class="form-label">Temperature (°C)</label>
      <input type="number" step="0.1"
             name="temp"
             value="<?php echo e(f('temp',$pediaForm)); ?>"
             class="form-control">
    </div>
    <div class="col-md-2">
      <label class="form-label">HR (bpm)</label>
      <input type="number"
             name="hr"
             value="<?php echo e(f('hr',$pediaForm)); ?>"
             class="form-control">
    </div>
    <div class="col-md-2">
      <label class="form-label">RR (cpm)</label>
      <input type="number"
             name="rr"
             value="<?php echo e(f('rr',$pediaForm)); ?>"
             class="form-control">
    </div>
    <div class="col-md-3">
      <label class="form-label">BP (mmHg)</label>
      <div class="input-group">
        <input type="number" name="bp_systolic" value="<?php echo e(f('bp_systolic',$pediaForm)); ?>" class="form-control" placeholder="Sys">
        <span class="input-group-text">/</span>
        <input type="number" name="bp_diastolic" value="<?php echo e(f('bp_diastolic',$pediaForm)); ?>" class="form-control" placeholder="Dia">
      </div>
    </div>
    <div class="col-md-2">
      <label class="form-label">O₂ Sat (%)</label>
      <input type="number" step="1"
             name="o2_sat"
             value="<?php echo e(f('o2_sat',$pediaForm)); ?>"
             class="form-control">
    </div>
  </div>

  <div class="row g-3 mb-4">
    <div class="col-md-4">
      <label class="form-label">Weight (kg)</label>
      <input type="number" step="0.01"
             name="weight"
             value="<?php echo e(f('weight',$pediaForm)); ?>"
             class="form-control">
    </div>
    <div class="col-md-4">
      <label class="form-label">Height/Length (cm)</label>
      <input type="number" step="0.1"
             name="height"
             value="<?php echo e(f('height',$pediaForm)); ?>"
             class="form-control">
    </div>
    <div class="col-md-4">
      <label class="form-label">MUAC (cm)</label>
      <input type="number" step="0.1"
             name="muac"
             value="<?php echo e(f('muac',$pediaForm)); ?>"
             class="form-control">
    </div>
  </div>

  <button type="submit" class="btn btn-primary">
    <?php echo e(isset($pediaForm) ? 'Update' : 'Save'); ?>

  </button>
</form>
<?php /**PATH C:\Users\MAURICIO\Documents\fabel\resources\views/opd_forms/pedia_triage/_form.blade.php ENDPATH**/ ?>