
<div class="card mb-4 shadow-sm">
  <div class="card-header bg-info text-white fw-semibold">
    How this Ensemble forecast was produced
  </div>
  <div class="card-body">
    <ol class="small mb-4">
      <li><strong>ARIMA component</strong> – trained on a 60-day window with order <code>(1,1,1)</code>, forecasting <?php echo e($steps); ?> days.</li>
      <li><strong>LSTM component</strong> – trained on the previous <?php echo e($windowSize); ?> days, forecasting <?php echo e($steps); ?> days.</li>
      <li><strong>Ensemble</strong> – element-wise average of ARIMA + LSTM predictions.</li>
      <li><strong>Historical mean</strong> – average daily count over the training window.</li>
      <li><strong>Final forecast</strong> – combined series plotted below.</li>
    </ol>

    <canvas id="ensembleChart" height="120"></canvas>
  </div>
</div>

<?php $__env->startPush('scripts'); ?>
  <script>
    document.addEventListener('DOMContentLoaded', () => {
      const ctx = document.getElementById('ensembleChart').getContext('2d');

      const labels = <?php echo json_encode($trend['ensemble']['dates'], 15, 512) ?>;
      const dataValues = <?php echo json_encode($trend['ensemble']['values'], 15, 512) ?>;

      new Chart(ctx, {
        type: 'line',
        data: {
          labels: labels,
          datasets: [{
            label: 'Ensemble <?php echo e($steps); ?>-day Forecast',
            data: dataValues,
            borderWidth: 2,
            fill: false,
          }]
        },
        options: {
          responsive: true,
          scales: {
            y: {
              beginAtZero: true,
              title: { display: true, text: 'Token visits / day' }
            },
            x: {
              title: { display: true, text: 'Date' }
            }
          },
          plugins: {
            legend: { display: false },
            tooltip: { mode: 'index' }
          }
        }
      });
    });
  </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\Users\MAURICIO\Documents\fabel\resources\views/trends/partials/ensemble.blade.php ENDPATH**/ ?>