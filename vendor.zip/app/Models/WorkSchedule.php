<?php

class WorkSchedule extends Schedule
{
  
}